import React    from 'react';
import ReactDOM from 'react-dom';

import Dashboard       from './components/dashboard';

ReactDOM.render( <Dashboard/>, document.getElementById( 'yith-pos-admin-root' ) );