export default Object.assign( {}, {
    enabled              : false,
    priceIncludesTax     : true,
    showPriceIncludingTax: false,
    classesAndRates      : {},
    classes              : [],
    classesLabels        : [],
    roundAtSubtotal      : false
} );