<?php
/**
 * Functions
 *
 * @author  YITH
 * @package YITH\POS\Functions
 */

defined( 'YITH_POS' ) || exit;

require_once 'functions.yith-pos-core.php';
require_once 'functions.yith-pos-objects.php';
require_once 'functions.yith-pos-caps.php';
require_once 'functions.yith-pos-template.php';
require_once 'functions.yith-pos-registers-and-users.php';
require_once 'functions.yith-pos-deprecated.php';
